import cv2, numpy as np, os

Q = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float32)

for f in ["message_bits.txt", "quantized.npy"]:
    if not os.path.exists(f):
        print(f"Thieu file {f}! Chay cac buoc truoc.")
        exit(1)

with open("message_bits.txt") as f:
    for line in f:
        if line.startswith("Binary"):
            bits = line.split(":")[1].strip()
            break

all_quant = np.load("quantized.npy").copy()
h, w    = all_quant.shape
bit_idx = 0
ac_pos  = [(r, c) for r in range(8) for c in range(8) if not (r == 0 and c == 0)]
log     = []

for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        if bit_idx >= len(bits):
            break
        for (r, c) in ac_pos:
            if bit_idx >= len(bits):
                break
            orig = all_quant[i+r, j+c]
            bit  = int(bits[bit_idx])
            val  = int(orig)
            if bit == 1:
                if val % 2 == 0: val += 1
            else:
                if val % 2 != 0: val -= 1
            all_quant[i+r, j+c] = val
            if orig != val:
                log.append(f"Block({i},{j}) AC[{r},{c}]: {orig} -> {val}  (bit={bit})")
            bit_idx += 1

np.save("embedded.npy", all_quant)

with open("embedded.txt", "w") as f:
    f.write(f"Tong so bit da nhung: {bit_idx}\n\n")
    f.write("Vi du cac he so AC bi thay doi LSB:\n")
    for line in log[:20]:
        f.write(line + "\n")
    if len(log) > 20:
        f.write(f"... va {len(log)-20} thay doi khac\n")

print(f"Da nhung {bit_idx} bits vao he so AC")
print(f"So he so AC bi thay doi: {len(log)}")
