import cv2, numpy as np, os

Q = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float32)

if not os.path.exists("embedded.npy"):
    print("Thieu file embedded.npy! Chay embed.py truoc.")
    exit(1)

all_quant = np.load("embedded.npy")
h, w = all_quant.shape

out = np.zeros((h, w), dtype=np.float32)
for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        q       = all_quant[i:i+8, j:j+8].astype(np.float32)
        dequant = q * Q
        idct    = cv2.idct(dequant) + 128
        out[i:i+8, j:j+8] = np.clip(idct, 0, 255)

cv2.imwrite("stego.jpg", out)
print("Buoc 1: Dequantization  (nhan Q tra lai)")
print("Buoc 2: IDCT            (chuyen ve mien khong gian)")
print("Buoc 3: Dich muc +128   (tra ve pixel 0-255)")
print("Da tao stego.jpg thanh cong!")
