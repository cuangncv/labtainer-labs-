msg  = "PTIT"
bits = ''.join(format(ord(c), '08b') for c in msg) + '00000000'

print(f"Thong diep : {msg}")
print(f"Binary     : {bits}")
print(f"So bit can giau: {len(bits)}")
print()
for c in msg:
    b = format(ord(c), '08b')
    print(f"  '{c}' (ASCII {ord(c)}) -> {b}")

with open("message_bits.txt", "w") as f:
    f.write(f"Message: {msg}\n")
    f.write(f"Binary : {bits}\n\n")
    for c in msg:
        f.write(f"  '{c}' = {format(ord(c),'08b')}\n")

print("\nDa luu vao message_bits.txt")
