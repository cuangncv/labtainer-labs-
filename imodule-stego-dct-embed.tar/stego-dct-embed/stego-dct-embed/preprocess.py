import cv2, sys, numpy as np

if len(sys.argv) < 2:
    print("Usage: python3 preprocess.py input.jpg")
    exit(1)

img = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
if img is None:
    print("Khong doc duoc anh!")
    exit(1)

h, w = img.shape
print(f"Kich thuoc anh: {w}x{h} pixels")
print(f"So block 8x8: {(h//8) * (w//8)}")

with open("blocks.txt", "w") as f:
    for i in range(0, h - 7, 8):
        for j in range(0, w - 7, 8):
            block = img[i:i+8, j:j+8]
            f.write(f"Block ({i},{j}):\n")
            f.write(np.array2string(block) + "\n\n")

print("Da luu cac block vao blocks.txt")
