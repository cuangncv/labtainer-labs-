import cv2, numpy as np

orig  = cv2.imread("input.jpg",  cv2.IMREAD_GRAYSCALE).astype(np.float32)
stego = cv2.imread("stego.jpg",  cv2.IMREAD_GRAYSCALE).astype(np.float32)

if orig.shape != stego.shape:
    print("Hai anh khac kich thuoc!")
    exit(1)

diff = np.abs(orig - stego)
mse  = np.mean((orig - stego) ** 2)
psnr = 10 * np.log10(255**2 / mse) if mse > 0 else float('inf')

print("=" * 40)
print("     SO SANH ANH GOC vs STEGO")
print("=" * 40)
print(f"Sai khac trung binh (MAE) : {diff.mean():.4f}")
print(f"Sai khac lon nhat         : {diff.max():.0f} / 255")
print(f"So pixel bi thay doi      : {int(np.sum(diff > 0))}")
print(f"PSNR                      : {psnr:.2f} dB")
print("-" * 40)
if psnr > 40:
    print("-> Chat luong rat tot: thong diep hoan toan an")
elif psnr > 30:
    print("-> Chat luong tot: kho phat hien bang mat thuong")
else:
    print("-> Chat luong trung binh")
print("=" * 40)
