import cv2, numpy as np, os

Q = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float32)

if not os.path.exists("dct_coeffs.npy"):
    print("Chua co dct_coeffs.npy! Chay dct.py truoc.")
    exit(1)

all_dct = np.load("dct_coeffs.npy")
h, w = all_dct.shape
total = (h // 8) * (w // 8)

all_quant = np.zeros_like(all_dct, dtype=int)
for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        dct = all_dct[i:i+8, j:j+8]
        all_quant[i:i+8, j:j+8] = np.round(dct / Q).astype(int)

np.save("quantized.npy", all_quant)

MAX_LOG = 10
selected = []
for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        q = all_quant[i:i+8, j:j+8]
        nonzero_ac = np.count_nonzero(q) - (1 if q[0,0] != 0 else 0)
        selected.append((nonzero_ac, i, j, q))

selected.sort(key=lambda x: -x[0])

with open("quantized.txt", "w") as f:
    f.write(f"Tong so block: {total}\n")
    f.write(f"Hien thi {MAX_LOG} block con nhieu AC != 0 nhat\n\n")
    for (nz, i, j, q) in selected[:MAX_LOG]:
        f.write(f"Block ({i},{j}) - DC={q[0,0]}, AC != 0: {nz}\n")
        f.write(np.array2string(q) + "\n\n")

print(f"Tong so block: {total}")
print("Da luong tu hoa toan bo he so DCT")
