import cv2, numpy as np

img = cv2.imread("input.jpg", cv2.IMREAD_GRAYSCALE)
if img is None:
    print("Khong doc duoc input.jpg!")
    exit(1)

img_f = img.astype(np.float32) - 128
h, w  = img_f.shape
total = (h // 8) * (w // 8)

all_dct = np.zeros_like(img_f)
for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        block = img_f[i:i+8, j:j+8]
        all_dct[i:i+8, j:j+8] = cv2.dct(block)

np.save("dct_coeffs.npy", all_dct)

MAX_LOG = 10
selected = []
for i in range(0, h - 7, 8):
    for j in range(0, w - 7, 8):
        dct = all_dct[i:i+8, j:j+8]
        ac_energy = np.sum(np.abs(dct)) - abs(dct[0,0])
        selected.append((ac_energy, i, j, dct))

selected.sort(key=lambda x: -x[0])

with open("dct.txt", "w") as f:
    f.write(f"Tong so block: {total}\n")
    f.write(f"Hien thi {MAX_LOG} block co nhieu nang luong AC nhat\n\n")
    for (_, i, j, dct) in selected[:MAX_LOG]:
        f.write(f"Block ({i},{j}):\n")
        f.write(f"  DC = {dct[0,0]:.1f}\n")
        f.write(f"  AC max = {np.max(np.abs(dct[1:])):.1f}\n")
        f.write(np.array2string(dct, precision=1, suppress_small=True, max_line_width=120) + "\n\n")

print(f"Tong so block: {total}")
print("Da thuc hien DCT cho toan bo anh")
