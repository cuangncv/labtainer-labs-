
from PIL import Image
import numpy as np
from scipy.fftpack import dct
import sys

fname = sys.argv[1] if len(sys.argv) > 1 else 'stego.png'

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
])

def dct2(block):
    return dct(dct(block.T, norm='ortho').T, norm='ortho')

def zigzag(n=8):
    idx = []
    for s in range(2*n-1):
        if s % 2 == 0:
            for i in range(min(s,n-1), max(0,s-n+1)-1, -1):
                idx.append((i, s-i))
        else:
            for i in range(max(0,s-n+1), min(s,n-1)+1):
                idx.append((i, s-i))
    return idx

ZIGZAG = zigzag()
EMBED_POS = [60, 61, 62]

img = Image.open(fname).convert('L')
arr = np.array(img, dtype=float)
h, w = arr.shape

bits = []
for by in range(0, h-7, 8):
    for bx in range(0, w-7, 8):
        block = arr[by:by+8, bx:bx+8] - 128
        D = dct2(block)
        C = np.round(D / Q50).astype(int)
        zz = [C[r][c] for r,c in ZIGZAG]
        for pos in EMBED_POS:
            # TODO: Trich bit LSB bang Modulo 2
            # Goi y: gia tri tuyet doi cua he so chia lay du cho 2
            bit = ???
            bits.append(bit)

print("[Buoc 2] Trich bit LSB theo Zigzag")
print(f"[*] Vi tri giau tin : {EMBED_POS}")
print(f"[*] Tong bit        : {len(bits)}")
print(f"[*] 24 bit dau      : {''.join(map(str,bits[:24]))}")
print(f"[*] Ky tu dau       : {chr(int(''.join(map(str,bits[:8])),2))}")
print("[→] Trich xuat bit thanh cong")
