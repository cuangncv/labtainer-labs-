from PIL import Image
import numpy as np
from scipy.fftpack import dct
import sys

fname = sys.argv[1] if len(sys.argv) > 1 else 'stego.png'

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
])

def dct2(block):
    return dct(dct(block.T, norm='ortho').T, norm='ortho')

img = Image.open(fname).convert('L')
arr = np.array(img, dtype=float)
block = arr[0:8, 0:8]
D = dct2(block - 128)

# TODO: Luong tu hoa ma tran DCT
# Goi y: chia D cho Q50 roi lam tron thanh so nguyen
# dung np.round() va .astype(int)
C = ???

print("[Buoc 1] Bien doi DCT + Luong tu hoa")
print("\nPixel goc (khoi 0,0):")
print(block.astype(int))
print("\nSau DCT:")
print(np.round(D, 1))
print("\nSau luong tu hoa:")
print(C)
print("\n[→] He so nguyen san sang trich LSB")
