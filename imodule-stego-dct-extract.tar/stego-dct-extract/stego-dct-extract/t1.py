from PIL import Image
import numpy as np
import sys

fname = sys.argv[1] if len(sys.argv) > 1 else 'stego.png'

img = Image.open(fname).convert('L')
arr = np.array(img, dtype=float)
h, w = arr.shape

# TODO: Tinh so khoi 8x8
# Goi y: chieu cao chia 8 nhan chieu rong chia 8
num_blocks = ???

print("=" * 40)
print(f"[*] File       : {fname}")
print(f"[*] Kich thuoc : {w} x {h} pixel")
print(f"[*] Min pixel  : {int(arr.min())}")
print(f"[*] Max pixel  : {int(arr.max())}")
print(f"[*] Trung binh : {arr.mean():.1f}")
print(f"[*] So khoi 8x8: {num_blocks} khoi")
print("=" * 40)
print("[→] Anh hop le, san sang xu ly")
