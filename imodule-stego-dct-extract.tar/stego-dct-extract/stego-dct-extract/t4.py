from PIL import Image
import numpy as np
from scipy.fftpack import dct
import sys

fname   = sys.argv[1] if len(sys.argv) > 1 else 'stego.png'
outfile = sys.argv[2] if len(sys.argv) > 2 else 'output.txt'

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
])

def dct2(block):
    return dct(dct(block.T, norm='ortho').T, norm='ortho')

def zigzag(n=8):
    idx = []
    for s in range(2*n-1):
        if s % 2 == 0:
            for i in range(min(s,n-1), max(0,s-n+1)-1, -1):
                idx.append((i, s-i))
        else:
            for i in range(max(0,s-n+1), min(s,n-1)+1):
                idx.append((i, s-i))
    return idx

ZIGZAG = zigzag()
EMBED_POS = [60, 61, 62]

img = Image.open(fname).convert('L')
arr = np.array(img, dtype=float)
h, w = arr.shape

# Thu thap tat ca bits (da hoan chinh, khong can sua)
bits = []
for by in range(0, h-7, 8):
    for bx in range(0, w-7, 8):
        block = arr[by:by+8, bx:bx+8] - 128
        D = dct2(block)
        C = np.round(D / Q50).astype(int)
        zz = [C[r][c] for r,c in ZIGZAG]
        for pos in EMBED_POS:
            bits.append(abs(zz[pos]) % 2)

print("[Buoc 3] Tai tao thong diep tu chuoi bit")
print("[1] Da ghep cac bit theo thu tu cac khoi")
print("[2] Gom nhom 8 bit va giai ma tung ky tu:")

message = ''
for i in range(0, len(bits)-7, 8):
    byte_bits = bits[i:i+8]

    # TODO: Chuyen 8 bit thanh ky tu
    # Goi y: dung int('chuoi_bit', 2) de doi nhi phan → so nguyen
    #        dung chr(val) de doi so nguyen → ky tu
    #        dung break khi val == 0 (ky tu ket thuc)
    val = ???
    if val == 0:
        break
    message += chr(val)

print(f"[3] Thong diep giai ma: {message}")

with open(outfile, 'w') as f:
    f.write(message)
print(f"[✓] Da luu vao {outfile}")
