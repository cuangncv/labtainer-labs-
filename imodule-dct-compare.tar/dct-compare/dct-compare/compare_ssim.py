import sys
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim

def calc_ssim(a, b):
    return ssim(a, b, data_range=255, channel_axis=2)

cover = np.array(Image.open(sys.argv[1]).convert('RGB'))
lsb   = np.array(Image.open(sys.argv[2]).convert('RGB'))
jsteg = np.array(Image.open(sys.argv[3]).convert('RGB'))
f5    = np.array(Image.open(sys.argv[4]).convert('RGB'))

print(f"{'Phuong phap':<12} {'SSIM'}")
print("-"*24)
print(f"{'LSB-DCT':<12} {calc_ssim(cover,lsb):.6f}")
print(f"{'JSteg':<12} {calc_ssim(cover,jsteg):.6f}")
print(f"{'Mini-F5':<12} {calc_ssim(cover,f5):.6f}")
