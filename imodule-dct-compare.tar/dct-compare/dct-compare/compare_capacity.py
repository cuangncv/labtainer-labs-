import sys
import numpy as np
from PIL import Image
from scipy.fft import dctn

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float64)

AC_POS = [(1,1),(2,0),(0,2),(1,2),(2,1),(3,0),(0,3),(4,0),(0,4),(3,1)]

img = Image.open(sys.argv[1]).convert('RGB')
channel = np.array(img.split()[0], dtype=np.float64)
h, w = channel.shape

lsb_cap = jsteg_cap = 0
nonzero = 0
for bi in range(h//8):
    for bj in range(w//8):
        block = channel[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        D = dctn(block, norm='ortho')
        C = np.round(D / Q50).astype(np.int32)
        for (r,c) in AC_POS:
            lsb_cap += 1
            if C[r,c] != 0 and C[r,c] != 1 and C[r,c] != -1:
                jsteg_cap += 1
            if C[r,c] != 0:
                nonzero += 1

# Mini-F5: 2 bits per 3 coefficients
f5_cap = (nonzero // 3) * 2

print(f"{'Phuong phap':<12} {'Capacity (bits)':<18} {'Capacity (bytes)'}")
print("-"*48)
print(f"{'LSB-DCT':<12} {lsb_cap:<18} {lsb_cap//8}")
print(f"{'JSteg':<12} {jsteg_cap:<18} {jsteg_cap//8}")
print(f"{'Mini-F5':<12} {f5_cap:<18} {f5_cap//8}")
