import sys
import numpy as np
from PIL import Image
from scipy.fft import dctn, idctn

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float64)

AC_POS = [(1,1),(2,0),(0,2),(1,2),(2,1),(3,0),(0,3),(4,0),(0,4),(3,1)]
KEY = 42

def get_ac_coeffs(channel):
    h, w = channel.shape
    coords = []
    vals = []
    for bi in range(h // 8):
        for bj in range(w // 8):
            block = channel[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
            D = dctn(block, norm='ortho')
            C = np.round(D / Q50).astype(np.int32)
            for (r, c) in AC_POS:
                if C[r,c] != 0:
                    coords.append((bi, bj, r, c))
                    vals.append(C[r,c])
    return coords, vals

def embed_channel(channel, bits):
    h, w = channel.shape
    # reconstruct block array
    blocks = {}
    for bi in range(h // 8):
        for bj in range(w // 8):
            block = channel[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
            D = dctn(block, norm='ortho')
            blocks[(bi,bj)] = np.round(D / Q50).astype(np.int32)

    # lay tat ca he so AC khac 0
    coords = []
    for bi in range(h // 8):
        for bj in range(w // 8):
            C = blocks[(bi,bj)]
            for (r, c) in AC_POS:
                if C[r,c] != 0:
                    coords.append((bi, bj, r, c))

    # permutation straddling
    rng = np.random.default_rng(KEY)
    perm = rng.permutation(len(coords))
    coords = [coords[i] for i in perm]

    # matrix embedding (1,2,3): nhung 2 bit vao 3 he so
    bit_idx = 0
    changed_blocks = set()
    i = 0
    while i + 2 < len(coords) and bit_idx + 1 < len(bits):
        bi1,bj1,r1,c1 = coords[i]
        bi2,bj2,r2,c2 = coords[i+1]
        bi3,bj3,r3,c3 = coords[i+2]

        h1 = blocks[(bi1,bj1)][r1,c1]
        h2 = blocks[(bi2,bj2)][r2,c2]
        h3 = blocks[(bi3,bj3)][r3,c3]

        b1 = int(bits[bit_idx])
        b2 = int(bits[bit_idx+1])

        p1 = (h1 & 1) ^ (h2 & 1)
        p2 = (h2 & 1) ^ (h3 & 1)

        if p1 == b1 and p2 == b2:
            pass
        elif p1 != b1 and p2 == b2:
            new = (h1 & ~1) | b1
            if new == 0:
                i += 3
                continue
            blocks[(bi1,bj1)][r1,c1] = new
            changed_blocks.add((bi1,bj1))
        elif p1 == b1 and p2 != b2:
            new = (h3 & ~1) | (b2 ^ (h2 & 1))
            if new == 0:
                i += 3
                continue
            blocks[(bi3,bj3)][r3,c3] = new
            changed_blocks.add((bi3,bj3))
        else:
            new = (h2 & ~1) | b2
            if new == 0:
                i += 3
                continue
            blocks[(bi2,bj2)][r2,c2] = new
            changed_blocks.add((bi2,bj2))

        bit_idx += 2
        i += 3

    # reconstruct image
    stego = channel.astype(np.float64).copy()
    for (bi,bj) in changed_blocks:
        C = blocks[(bi,bj)]
        stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8] = idctn(C.astype(np.float64)*Q50, norm='ortho') + 128.0

    return np.clip(stego, 0, 255).astype(np.uint8)

img = Image.open(sys.argv[1]).convert('RGB')
r, g, b = [np.array(c) for c in img.split()]
bits = np.unpackbits(np.frombuffer((sys.argv[2]+'\x00').encode('utf-8'), dtype=np.uint8))
h, w = r.shape

r_new = embed_channel(r, bits)
Image.merge('RGB',[Image.fromarray(r_new),Image.fromarray(g),Image.fromarray(b)]).save(sys.argv[3])
