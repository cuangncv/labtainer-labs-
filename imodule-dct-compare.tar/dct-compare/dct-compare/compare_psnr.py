import sys
import numpy as np
from PIL import Image

def psnr(a, b):
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64))**2)
    if mse == 0: return float('inf'), 0
    return 10*np.log10(255**2/mse), mse

cover = np.array(Image.open(sys.argv[1]).convert('RGB'))
lsb   = np.array(Image.open(sys.argv[2]).convert('RGB'))
jsteg = np.array(Image.open(sys.argv[3]).convert('RGB'))
f5    = np.array(Image.open(sys.argv[4]).convert('RGB'))

p1,m1 = psnr(cover, lsb)
p2,m2 = psnr(cover, jsteg)
p3,m3 = psnr(cover, f5)

print(f"{'Phuong phap':<12} {'PSNR (dB)':<12} {'MSE':<10}")
print("-"*36)
print(f"{'LSB-DCT':<12} {p1:<12.2f} {m1:<10.4f}")
print(f"{'JSteg':<12} {p2:<12.2f} {m2:<10.4f}")
print(f"{'Mini-F5':<12} {p3:<12.2f} {m3:<10.4f}")
