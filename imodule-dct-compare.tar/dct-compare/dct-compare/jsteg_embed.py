import sys
import numpy as np
from PIL import Image
from scipy.fft import dctn, idctn

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float64)

AC_POS = [(1,1),(2,0),(0,2),(1,2),(2,1),(3,0),(0,3),(4,0),(0,4),(3,1)]

def embed_channel(channel, bits):
    h, w = channel.shape
    stego = channel.astype(np.float64).copy()
    bit_idx = 0
    for bi in range(h // 8):
        for bj in range(w // 8):
            if bit_idx >= len(bits): break
            block = stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
            D = dctn(block, norm='ortho')
            C = np.round(D / Q50).astype(np.int32)
            changed = False
            for (r, c) in AC_POS:
                if bit_idx >= len(bits): break
                if C[r,c] == 0 or C[r,c] == 1 or C[r,c] == -1:
                    continue
                new_coeff = (C[r,c] & ~1) | int(bits[bit_idx])
                if new_coeff != C[r,c]:
                    C[r,c] = new_coeff
                    changed = True
                bit_idx += 1
            if changed:
                stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8] = idctn(C.astype(np.float64)*Q50, norm='ortho') + 128.0
    return np.clip(stego, 0, 255).astype(np.uint8)

img = Image.open(sys.argv[1]).convert('RGB')
r, g, b = [np.array(c) for c in img.split()]
bits = np.unpackbits(np.frombuffer((sys.argv[2]+'\x00').encode('utf-8'), dtype=np.uint8))
h, w = r.shape
capacity = (h//8)*(w//8)*len(AC_POS)
if len(bits) > capacity:
    print(f"Loi: can {len(bits)} bits, anh chua toi da {capacity} bits"); sys.exit(1)
r_new = embed_channel(r, bits)
Image.merge('RGB',[Image.fromarray(r_new),Image.fromarray(g),Image.fromarray(b)]).save(sys.argv[3])
