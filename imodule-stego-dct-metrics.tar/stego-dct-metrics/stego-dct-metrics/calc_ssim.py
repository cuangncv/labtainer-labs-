import sys
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim

a = np.array(Image.open(sys.argv[1]).convert('RGB'))
b = np.array(Image.open(sys.argv[2]).convert('RGB'))
val = ssim(a, b, data_range=255, channel_axis=2)
print(f"SSIM: {val:.9f}")
