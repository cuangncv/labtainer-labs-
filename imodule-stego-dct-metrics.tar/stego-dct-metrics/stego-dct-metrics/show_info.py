import sys
from PIL import Image
import numpy as np

img = Image.open(sys.argv[1]).convert('RGB')
arr = np.array(img)
print(f"File  : {sys.argv[1]}")
print(f"Size  : {img.size[0]} x {img.size[1]}")
print(f"Mode  : {img.mode}")
print(f"Mean  : {arr.mean():.2f}")
print(f"Min   : {arr.min()}  Max: {arr.max()}")
