import sys
import numpy as np
from PIL import Image

a = np.array(Image.open(sys.argv[1]).convert('RGB'), dtype=np.float64)
b = np.array(Image.open(sys.argv[2]).convert('RGB'), dtype=np.float64)
mse = np.mean((a - b) ** 2)
if mse == 0:
    print("PSNR: inf dB (hai anh giong het)")
else:
    psnr = 10 * np.log10(255**2 / mse)
    print(f"PSNR: {psnr:.2f} dB")
