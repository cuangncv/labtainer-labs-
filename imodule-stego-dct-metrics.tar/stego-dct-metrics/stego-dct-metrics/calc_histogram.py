import sys
import numpy as np
from PIL import Image

a = np.array(Image.open(sys.argv[1]).convert('RGB'))
b = np.array(Image.open(sys.argv[2]).convert('RGB'))

diff = 0
for ch in range(3):
    h1, _ = np.histogram(a[:,:,ch], bins=256, range=(0,255))
    h2, _ = np.histogram(b[:,:,ch], bins=256, range=(0,255))
    diff += np.sum(np.abs(h1.astype(np.float64) - h2.astype(np.float64)))

print(f"Hist.Diff: {diff:.0f}")
