import sys
import numpy as np
from PIL import Image

a = np.array(Image.open(sys.argv[1]).convert('RGB'), dtype=np.float64)
b = np.array(Image.open(sys.argv[2]).convert('RGB'), dtype=np.float64)
mse = np.mean((a - b) ** 2)
print(f"MSE : {mse:.4f}")
