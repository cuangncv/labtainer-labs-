q1 = input("Phương pháp nào cho ảnh stego có PSNR cao hơn khi giấu cùng lượng dữ liệu nhỏ? (1=LSB miền không gian / 2=LSB trên hệ số DCT): ").strip()
q2 = input("Phương pháp nào có dung lượng giấu tin (Capacity) lớn hơn? (1=LSB miền không gian / 2=LSB trên hệ số DCT): ").strip()
q3 = input("Phương pháp nào khó bị phát hiện hơn? (1=LSB miền không gian / 2=LSB trên hệ số DCT): ").strip()

with open('ketluan.txt', 'w') as f:
    f.write(f"Q1:{q1} Q2:{q2} Q3:{q3}\n")

print("Da luu ketluan.txt")
