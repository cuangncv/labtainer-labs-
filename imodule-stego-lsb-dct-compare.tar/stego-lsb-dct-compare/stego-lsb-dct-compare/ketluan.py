q1 = input("Thuật toán nào cho ảnh stego có PSNR cao hơn khi giấu cùng lượng dữ liệu nhỏ? (1=LSB / 2=DCT): ").strip()
q2 = input("Thuật toán nào có dung lượng giấu tin (Capacity) lớn hơn? (1=LSB / 2=DCT): ").strip()
q3 = input("Thuật toán nào khó bị phát hiện hơn? (1=LSB / 2=DCT): ").strip()

with open('ketluan.txt', 'w') as f:
    f.write(f"Q1:{q1} Q2:{q2} Q3:{q3}\n")

print("Da luu ketluan.txt")
