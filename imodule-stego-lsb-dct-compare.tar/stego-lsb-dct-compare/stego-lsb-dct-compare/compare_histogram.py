import sys
import numpy as np
from PIL import Image

def hist_diff(a, b):
    ha, _ = np.histogram(a, bins=256, range=(0,255))
    hb, _ = np.histogram(b, bins=256, range=(0,255))
    return int(np.sum(np.abs(ha - hb)))

cover = np.array(Image.open(sys.argv[1]).convert('L'), dtype=np.float64)
slsb  = np.array(Image.open(sys.argv[2]).convert('L'), dtype=np.float64)
sdct  = np.array(Image.open(sys.argv[3]).convert('L'), dtype=np.float64)


print(f"LSB: {hist_diff(cover,slsb)}")
print(f"DCT: {hist_diff(cover,sdct)}")
