import sys
import numpy as np
from PIL import Image

def psnr(a, b):
    mse = np.mean((a - b) ** 2)
    return 10 * np.log10(255.0**2 / mse) if mse > 0 else float('inf'), mse

cover = np.array(Image.open(sys.argv[1]).convert('L'), dtype=np.float64)
slsb  = np.array(Image.open(sys.argv[2]).convert('L'), dtype=np.float64)
sdct  = np.array(Image.open(sys.argv[3]).convert('L'), dtype=np.float64)

p_lsb, m_lsb = psnr(cover, slsb)
p_dct, m_dct = psnr(cover, sdct)

print(f"LSB: MSE={m_lsb:.4f}  PSNR={p_lsb:.2f} dB")
print(f"DCT: MSE={m_dct:.4f}  PSNR={p_dct:.2f} dB")
