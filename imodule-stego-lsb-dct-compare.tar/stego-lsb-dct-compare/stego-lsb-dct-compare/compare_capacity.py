import sys
from PIL import Image

img = Image.open(sys.argv[1]).convert('L')
w, h = img.size
cap_lsb = w * h
cap_dct = (h // 8) * (w // 8) * 10

print(f"LSB: {cap_lsb} bits = {cap_lsb//8} bytes")
print(f"DCT: {cap_dct} bits = {cap_dct//8} bytes")
