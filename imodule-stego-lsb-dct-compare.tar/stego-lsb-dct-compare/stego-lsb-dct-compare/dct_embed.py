import sys
import numpy as np
from PIL import Image
from scipy.fft import dctn, idctn

AC_POS = [(1,1),(2,0),(0,2),(1,2),(2,1),(3,0),(0,3),(4,0),(0,4),(3,1)]
cover  = np.array(Image.open(sys.argv[1]).convert('L'), dtype=np.float64)
secret = np.array(Image.open(sys.argv[2]).convert('L'), dtype=np.uint8)
bits   = np.unpackbits(secret.flatten())
h, w   = cover.shape
stego  = cover.copy()
bit_idx = 0
for bi in range(h // 8):
    for bj in range(w // 8):
        if bit_idx >= len(bits): break
        block = stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8].copy()
        dct_b = dctn(block, norm='ortho')
        changed = False
        for (r, c) in AC_POS:
            if bit_idx >= len(bits): break
            coeff_int = int(round(dct_b[r, c]))
            new_val   = (coeff_int & ~1) | int(bits[bit_idx])
            if new_val != coeff_int:
                dct_b[r, c] = float(new_val)
                changed = True
            bit_idx += 1
        if changed:
            stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8] = idctn(dct_b, norm='ortho')
np.save(sys.argv[3].replace('.png', '.npy'), stego)
Image.fromarray(np.clip(stego, 0, 255).astype(np.uint8)).save(sys.argv[3])
print(f"DCT embed done: {sys.argv[3]}")
