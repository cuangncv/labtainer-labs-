import sys
import numpy as np
from PIL import Image

cover  = np.array(Image.open(sys.argv[1]).convert('L'), dtype=np.uint8)
secret = np.array(Image.open(sys.argv[2]).convert('L'), dtype=np.uint8)
bits   = np.unpackbits(secret.flatten())
stego  = cover.flatten().copy()
stego[:len(bits)] = (stego[:len(bits)] & 0xFE) | bits
Image.fromarray(stego.reshape(cover.shape)).save(sys.argv[3])
print(f"LSB embed done: {sys.argv[3]}")
